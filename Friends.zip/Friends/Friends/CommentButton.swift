//
//  CommentButton.swift
//  Friends
//
//  Created by Andrew Kim on 7/9/20.
//  Copyright © 2020 Rodrigo Velasco. All rights reserved.
//

import UIKit

class CommentButton: UIButton {
    var postID: String!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
